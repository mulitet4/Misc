# Project Architecture

## System Overview

```
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│   Browser   │ ◄─────► │   Next.js    │ ◄─────► │   Django    │
│   (User)    │  HTTP   │   Frontend   │   API   │   Backend   │
└─────────────┘         └──────────────┘         └─────────────┘
                              │                         │
                              │                         │
                        ┌─────▼──────┐           ┌─────▼──────┐
                        │  Monaco    │           │  Code      │
                        │  Editor    │           │  Executor  │
                        └────────────┘           └─────────────┘
                                                        │
                                                        │
                                                  ┌─────▼──────┐
                                                  │ Python/    │
                                                  │ GCC/G++    │
                                                  │ Subprocess │
                                                  └────────────┘
```

## Backend Architecture (Django)

### Components

1. **API Layer** (`executor/views.py`)
   - REST API endpoints
   - Request validation
   - Response formatting

2. **Execution Engine** (`executor/utils.py`)
   - `CodeExecutor`: Handles Python, C, C++ execution
   - `ASTGenerator`: Generates Python AST
   - Timeout management
   - Temporary file handling

3. **Data Layer** (`executor/models.py`)
   - `CodeExecution` model
   - Execution history storage
   - Audit trail

### API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/execute/` | POST | Execute code |
| `/api/ast/` | POST | Generate AST |
| `/api/history/` | GET | Get execution history |
| `/api/health/` | GET | Health check |

### Code Execution Flow

```
Request → Validation → Language Detection → Create Temp File
                                                    │
                                                    ▼
Response ◄── Format Results ◄── Capture Output ◄── Execute
```

## Frontend Architecture (Next.js)

### Components Structure

```
app/
├── layout.tsx          # Root layout
├── page.tsx           # Main page
└── globals.css        # Global styles

components/
├── CodeEditor.tsx     # Main editor component
├── ASTViewer.tsx      # AST visualization
└── ui/               # shadcn/ui components
    ├── button.tsx
    ├── card.tsx
    ├── tabs.tsx
    └── textarea.tsx

lib/
├── api.ts            # API client
└── utils.ts          # Utilities
```

### State Management

```typescript
// CodeEditor Component State
- language: Current programming language
- code: Code in editor
- input: stdin input
- output: Execution output
- error: Error messages
- executionTime: Performance metric
- astData: AST structure
- loading: UI state
```

### Data Flow

```
User Input → Monaco Editor → State Update → API Call
                                               │
                                               ▼
Display Results ◄── State Update ◄── API Response
```

## Technology Stack Details

### Backend Stack
- **Django 4.2**: Web framework
- **Django REST Framework**: API framework
- **SQLite**: Database (can be swapped for PostgreSQL)
- **Python subprocess**: Code execution
- **CORS Headers**: Cross-origin support

### Frontend Stack
- **Next.js 14**: React framework with App Router
- **TypeScript**: Type safety
- **TailwindCSS**: Utility-first CSS
- **shadcn/ui**: Component library
- **Monaco Editor**: VS Code's editor
- **Axios**: HTTP client
- **Lucide React**: Icons

## Security Features

1. **Timeout Protection**: 5-second execution limit
2. **Temporary Files**: Automatic cleanup
3. **Isolated Execution**: Each execution in separate process
4. **CORS**: Restricted to localhost
5. **Input Validation**: Request validation with DRF

## Performance Considerations

1. **Editor**: Monaco lazy loading
2. **API**: RESTful endpoints
3. **Database**: Indexed queries
4. **Execution**: Process pooling possible
5. **Frontend**: Next.js automatic optimization

## Extensibility

### Adding New Languages

1. Add language to `LANGUAGE_CHOICES` in models.py
2. Implement executor in `utils.py`
3. Add language option in frontend
4. Update Monaco language support

### Adding Features

- **Code Formatting**: Add prettier/black integration
- **Code Linting**: Integrate pylint/eslint
- **Collaboration**: Add WebSocket support
- **File Upload**: Support multi-file projects
- **Themes**: Add dark/light mode toggle

## Database Schema

```sql
CodeExecution
├── id (PK)
├── language (VARCHAR)
├── code (TEXT)
├── input_data (TEXT)
├── output (TEXT)
├── error (TEXT)
├── execution_time (FLOAT)
└── created_at (TIMESTAMP)
```

## Deployment Considerations

### Backend
- Use Gunicorn/uWSGI
- PostgreSQL for production
- Docker containerization
- Environment variables
- Nginx reverse proxy

### Frontend
- Vercel/Netlify deployment
- Environment variables
- CDN for static assets
- SSR/SSG optimization

### Security
- Sandbox code execution (Docker/VM)
- Rate limiting
- User authentication
- Code size limits
- Resource constraints

---

For implementation details, see the source code and README.md
