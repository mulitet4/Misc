import subprocess
import tempfile
import os
import time
import ast
import json
from pathlib import Path


class CodeExecutor:
    """Execute code in different languages with timeout and safety measures."""
    
    TIMEOUT = 5  # seconds
    
    @staticmethod
    def execute_python(code, input_data=""):
        """Execute Python code and return output, error, and execution time."""
        start_time = time.time()
        
        try:
            # Create a temporary file for the code
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(code)
                temp_file = f.name
            
            # Create a temporary file for input
            input_file = None
            if input_data:
                with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
                    f.write(input_data)
                    input_file = f.name
            
            # Execute the code
            try:
                if input_file:
                    with open(input_file, 'r') as stdin:
                        result = subprocess.run(
                            ['python3', temp_file],
                            stdin=stdin,
                            capture_output=True,
                            text=True,
                            timeout=CodeExecutor.TIMEOUT
                        )
                else:
                    result = subprocess.run(
                        ['python3', temp_file],
                        capture_output=True,
                        text=True,
                        timeout=CodeExecutor.TIMEOUT
                    )
                
                execution_time = time.time() - start_time
                
                return {
                    'output': result.stdout,
                    'error': result.stderr,
                    'execution_time': execution_time
                }
            
            except subprocess.TimeoutExpired:
                return {
                    'output': '',
                    'error': f'Execution timed out after {CodeExecutor.TIMEOUT} seconds',
                    'execution_time': CodeExecutor.TIMEOUT
                }
            
            finally:
                # Clean up temp files
                os.unlink(temp_file)
                if input_file:
                    os.unlink(input_file)
        
        except Exception as e:
            return {
                'output': '',
                'error': str(e),
                'execution_time': time.time() - start_time
            }
    
    @staticmethod
    def execute_c(code, input_data=""):
        """Compile and execute C code."""
        start_time = time.time()
        
        try:
            # Create temporary files
            with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
                f.write(code)
                source_file = f.name
            
            executable = source_file.replace('.c', '.out')
            
            # Compile
            compile_result = subprocess.run(
                ['gcc', source_file, '-o', executable],
                capture_output=True,
                text=True,
                timeout=CodeExecutor.TIMEOUT
            )
            
            if compile_result.returncode != 0:
                os.unlink(source_file)
                return {
                    'output': '',
                    'error': f'Compilation Error:\n{compile_result.stderr}',
                    'execution_time': time.time() - start_time
                }
            
            # Execute
            try:
                input_file = None
                if input_data:
                    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
                        f.write(input_data)
                        input_file = f.name
                
                if input_file:
                    with open(input_file, 'r') as stdin:
                        result = subprocess.run(
                            [executable],
                            stdin=stdin,
                            capture_output=True,
                            text=True,
                            timeout=CodeExecutor.TIMEOUT
                        )
                else:
                    result = subprocess.run(
                        [executable],
                        capture_output=True,
                        text=True,
                        timeout=CodeExecutor.TIMEOUT
                    )
                
                execution_time = time.time() - start_time
                
                return {
                    'output': result.stdout,
                    'error': result.stderr,
                    'execution_time': execution_time
                }
            
            except subprocess.TimeoutExpired:
                return {
                    'output': '',
                    'error': f'Execution timed out after {CodeExecutor.TIMEOUT} seconds',
                    'execution_time': CodeExecutor.TIMEOUT
                }
            
            finally:
                # Clean up
                os.unlink(source_file)
                if os.path.exists(executable):
                    os.unlink(executable)
                if input_file:
                    os.unlink(input_file)
        
        except Exception as e:
            return {
                'output': '',
                'error': str(e),
                'execution_time': time.time() - start_time
            }
    
    @staticmethod
    def execute_cpp(code, input_data=""):
        """Compile and execute C++ code."""
        start_time = time.time()
        
        try:
            # Create temporary files
            with tempfile.NamedTemporaryFile(mode='w', suffix='.cpp', delete=False) as f:
                f.write(code)
                source_file = f.name
            
            executable = source_file.replace('.cpp', '.out')
            
            # Compile
            compile_result = subprocess.run(
                ['g++', source_file, '-o', executable],
                capture_output=True,
                text=True,
                timeout=CodeExecutor.TIMEOUT
            )
            
            if compile_result.returncode != 0:
                os.unlink(source_file)
                return {
                    'output': '',
                    'error': f'Compilation Error:\n{compile_result.stderr}',
                    'execution_time': time.time() - start_time
                }
            
            # Execute
            try:
                input_file = None
                if input_data:
                    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
                        f.write(input_data)
                        input_file = f.name
                
                if input_file:
                    with open(input_file, 'r') as stdin:
                        result = subprocess.run(
                            [executable],
                            stdin=stdin,
                            capture_output=True,
                            text=True,
                            timeout=CodeExecutor.TIMEOUT
                        )
                else:
                    result = subprocess.run(
                        [executable],
                        capture_output=True,
                        text=True,
                        timeout=CodeExecutor.TIMEOUT
                    )
                
                execution_time = time.time() - start_time
                
                return {
                    'output': result.stdout,
                    'error': result.stderr,
                    'execution_time': execution_time
                }
            
            except subprocess.TimeoutExpired:
                return {
                    'output': '',
                    'error': f'Execution timed out after {CodeExecutor.TIMEOUT} seconds',
                    'execution_time': CodeExecutor.TIMEOUT
                }
            
            finally:
                # Clean up
                os.unlink(source_file)
                if os.path.exists(executable):
                    os.unlink(executable)
                if input_file:
                    os.unlink(input_file)
        
        except Exception as e:
            return {
                'output': '',
                'error': str(e),
                'execution_time': time.time() - start_time
            }


class ASTGenerator:
    """Generate Abstract Syntax Tree for Python code."""
    
    @staticmethod
    def generate_ast(code):
        """Parse Python code and return AST as JSON."""
        try:
            tree = ast.parse(code)
            return {
                'success': True,
                'ast': ASTGenerator._ast_to_dict(tree)
            }
        except SyntaxError as e:
            return {
                'success': False,
                'error': f'Syntax Error at line {e.lineno}: {e.msg}'
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def _ast_to_dict(node):
        """Convert AST node to dictionary representation."""
        if isinstance(node, ast.AST):
            result = {
                'type': node.__class__.__name__,
                'fields': {}
            }
            
            for field, value in ast.iter_fields(node):
                if isinstance(value, list):
                    result['fields'][field] = [ASTGenerator._ast_to_dict(item) for item in value]
                else:
                    result['fields'][field] = ASTGenerator._ast_to_dict(value)
            
            # Add position info if available
            if hasattr(node, 'lineno'):
                result['lineno'] = node.lineno
            if hasattr(node, 'col_offset'):
                result['col_offset'] = node.col_offset
            
            return result
        else:
            return node
