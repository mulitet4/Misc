'use client';

import CodeEditor from '@/components/CodeEditor';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Code2, Terminal, Zap } from 'lucide-react';

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2 flex items-center justify-center gap-3">
            <Terminal className="w-10 h-10" />
            Code Execution Lab
          </h1>
          <p className="text-muted-foreground text-lg">
            Execute Python, C, and C++ code with real-time output and AST visualization
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Code2 className="w-4 h-4" />
                Multiple Languages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Support for Python, C, and C++ with syntax highlighting
              </CardDescription>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Real-time Execution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Execute code instantly with execution time tracking
              </CardDescription>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                AST Visualization
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                View Abstract Syntax Tree for Python code
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Main Editor */}
        <CodeEditor />

        {/* Footer */}
        <div className="text-center mt-8 text-sm text-muted-foreground">
          <p>Built with Django, Next.js, TailwindCSS, and shadcn/ui</p>
        </div>
      </div>
    </main>
  );
}
